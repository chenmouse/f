
.onAttach <- function(libname, pkgname) {
    options(nCov2019.country = "China")
}
